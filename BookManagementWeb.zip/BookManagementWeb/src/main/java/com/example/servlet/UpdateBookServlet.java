package com.example.servlet;

import com.example.dao.BookDAO;
import com.example.model.Book;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/updateBook")
public class UpdateBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int bookID = Integer.parseInt(request.getParameter("id"));
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String publisher = request.getParameter("publisher");
        String isbn = request.getParameter("isbn");
        String genre = request.getParameter("genre"); // ✅ ADDED
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        Book updatedBook = new Book(bookID, title, author, publisher, isbn, genre, quantity); // ✅ FIXED
        BookDAO dao = new BookDAO();

        try {
            dao.update(updatedBook);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException("Database error while updating book", e);
        }

        response.sendRedirect("listBooks");
    }
}
