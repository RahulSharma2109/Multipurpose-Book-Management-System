package com.example.servlet;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.example.dao.BookDAO;
import com.example.model.Book;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/books")
public class BookServlet extends HttpServlet {
    private BookDAO dao = new BookDAO();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            List<Book> list = dao.listAll();
            req.setAttribute("bookList", list);
            req.getRequestDispatcher("books.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Book book = new Book(
            req.getParameter("title"),
            req.getParameter("author"),
            req.getParameter("publisher"),
            req.getParameter("isbn"),
            req.getParameter("genre"),
            Integer.parseInt(req.getParameter("quantity"))
        );
        try { dao.insert(book); }
        catch (SQLException e) { throw new ServletException(e); }
        resp.sendRedirect("books");
    }
}
