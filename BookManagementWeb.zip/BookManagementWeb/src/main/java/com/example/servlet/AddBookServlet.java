package com.example.servlet;

import com.example.dao.BookDAO;
import com.example.model.Book;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/addBook")
public class AddBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String publisher = request.getParameter("publisher");
        String isbn = request.getParameter("isbn");
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        Book newBook = new Book(title, author, publisher, isbn, isbn, quantity);
        BookDAO dao = new BookDAO();

        try {
            dao.insert(newBook); // This can throw SQLException
        } catch (SQLException e) {
            e.printStackTrace(); // Log error
            throw new ServletException("Database error while adding book", e); // Show friendly error
        }

        response.sendRedirect("listBooks");
    }
}
