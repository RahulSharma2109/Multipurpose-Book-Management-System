// BookDAO.java
package com.example.dao;

import com.example.model.Book;
import com.example.util.DBConnection;

import java.sql.*;
import java.util.*;

public class BookDAO {
    public void insert(Book book) throws SQLException {
        String sql = "INSERT INTO Books (Title, Author, Publisher, ISBN, Genre, Quantity) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getPublisher());
            ps.setString(4, book.getIsbn());
            ps.setString(5, book.getGenre());
            ps.setInt(6, book.getQuantity());
            ps.executeUpdate();
        }
    }

    public List<Book> listAll() throws SQLException {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM Books";
        try (Connection c = DBConnection.getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) {
                Book b = new Book(
                    rs.getInt("BookID"),
                    rs.getString("Title"),
                    rs.getString("Author"),
                    rs.getString("Publisher"),
                    rs.getString("ISBN"),
                    rs.getString("Genre"),
                    rs.getInt("Quantity")
                );
                list.add(b);
            }
        }
        return list;
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM Books WHERE BookID = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public void update(Book book) throws SQLException {
        String sql = "UPDATE Books SET Title=?, Author=?, Publisher=?, ISBN=?, Genre=?, Quantity=? WHERE BookID=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getPublisher());
            ps.setString(4, book.getIsbn());
            ps.setString(5, book.getGenre());
            ps.setInt(6, book.getQuantity());
            ps.setInt(7, book.getId());
            ps.executeUpdate();
        }
    }

    public Book get(int id) throws SQLException {
        String sql = "SELECT * FROM Books WHERE BookID = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Book(
                        rs.getInt("BookID"),
                        rs.getString("Title"),
                        rs.getString("Author"),
                        rs.getString("Publisher"),
                        rs.getString("ISBN"),
                        rs.getString("Genre"),
                        rs.getInt("Quantity")
                    );
                }
            }
        }
        return null;
    }
}
